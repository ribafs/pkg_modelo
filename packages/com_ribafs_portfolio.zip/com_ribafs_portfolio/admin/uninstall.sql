DROP TABLE IF EXISTS `#__ribafs_portfolio`
